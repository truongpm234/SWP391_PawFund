﻿using Microsoft.AspNetCore.Mvc;

namespace MyWebApp1.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PetCategoryController
{
    
}